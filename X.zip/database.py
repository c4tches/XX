import motor.motor_asyncio
import datetime
import os
from typing import Optional, Dict, Any, List
from bson import ObjectId
from pyrogram import Client

# MongoDB connection URI (set environment variable)
MONGO_URI = os.getenv("MONGO_URI", "mongodb+srv://ZenoBaby:ZenoBaby@zenobaby.sdec3jo.mongodb.net/?appName=ZenoBaby")
DB_NAME = os.getenv("DB_NAME", "ZenoBaby")

# Global MongoDB client
mongo_client = motor.motor_asyncio.AsyncIOMotorClient(MONGO_URI)
db = mongo_client[DB_NAME]

# Collections
users_col = db["users"]
proxies_col = db["user_proxies"]
sites_col = db["user_sites"]
keys_col = db["plans_keys"]
cards_col = db["card_stats"]

# Indexes for performance
async def init_db():
    """Initialize database indexes"""
    try:
        await users_col.create_index("user_id", unique=True)
        await proxies_col.create_index([("user_id", 1), ("proxy_url", 1)])
        await sites_col.create_index([("user_id", 1), ("site", 1)], unique=True)
        await keys_col.create_index("key", unique=True)
        await cards_col.create_index("checked_at")
        print("✅ Database indexes created/verified")
    except Exception as e:
        print(f"⚠️ Database initialization error: {e}")

# ---------- USER MANAGEMENT ----------
async def ensure_user(user_id: int) -> Dict:
    """Ensure user exists in database with default plans"""
    result = await users_col.update_one(
        {"user_id": user_id},
        {
            "$setOnInsert": {
                "plans": "noob",
                "plans_expiry": None,
                "banned": False,
                "joined_at": datetime.datetime.now(datetime.timezone.utc)
            }
        },
        upsert=True
    )
    return result

async def get_user_plans(user_id: int) -> str:
    """Get user's current plans (checks expiry)"""
    doc = await users_col.find_one({"user_id": user_id})
    if not doc:
        return "noob"
    
    plans = doc.get("plans", "noob")
    expiry = doc.get("plans_expiry")
    
    # Check if plans expired
    if expiry and isinstance(expiry, datetime.datetime):
        now = datetime.datetime.now(datetime.timezone.utc)
        if now > expiry.replace(tzinfo=datetime.timezone.utc):
            # Reset to noob if expired
            await users_col.update_one(
                {"user_id": user_id},
                {"$set": {"plans": "noob", "plans_expiry": None}}
            )
            return "noob"
    
    return plans

async def set_user_plans(user_id: int, plans: str, days: int = 0):
    """Set user plans with optional expiry days"""
    expiry = None
    if days > 0:
        expiry = datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(days=days)
    
    await users_col.update_one(
        {"user_id": user_id},
        {"$set": {
            "plans": plans,
            "plans_expiry": expiry,
            "plans_updated_at": datetime.datetime.now(datetime.timezone.utc)
        }}
    )

async def is_banned_user(user_id: int) -> bool:
    """Check if user is banned"""
    doc = await users_col.find_one({"user_id": user_id})
    return doc.get("banned", False) if doc else False

async def ban_user(user_id: int, admin_id: int):
    """Ban a user"""
    await ensure_user(user_id)  # Ensure user exists
    await users_col.update_one(
        {"user_id": user_id},
        {"$set": {
            "banned": True,
            "banned_by": admin_id,
            "banned_at": datetime.datetime.now(datetime.timezone.utc)
        }}
    )

async def unban_user(user_id: int):
    """Unban a user"""
    await users_col.update_one(
        {"user_id": user_id},
        {
            "$set": {"banned": False},
            "$unset": {"banned_by": "", "banned_at": ""}
        }
    )

# ---------- PROXY MANAGEMENT ----------
async def add_proxy_db(user_id: int, proxy_data: Dict):
    """Add a proxy to user's collection"""
    doc = {
        "user_id": user_id,
        "ip": proxy_data['ip'],
        "port": proxy_data['port'],
        "username": proxy_data.get('username'),
        "password": proxy_data.get('password'),
        "proxy_url": proxy_data['proxy_url'],
        "proxy_type": proxy_data.get('type', 'http'),
        "added_at": datetime.datetime.now(datetime.timezone.utc)
    }
    await proxies_col.insert_one(doc)

async def get_random_proxy(user_id: int) -> Optional[Dict]:
    """Get a random proxy for user"""
    pipeline = [
        {"$match": {"user_id": user_id}},
        {"$sample": {"size": 1}}
    ]
    cursor = proxies_col.aggregate(pipeline)
    docs = await cursor.to_list(length=1)
    
    if docs:
        p = docs[0]
        return {
            'ip': p['ip'],
            'port': p['port'],
            'username': p.get('username'),
            'password': p.get('password'),
            'proxy_url': p['proxy_url'],
            'type': p.get('proxy_type', 'http')
        }
    return None

async def get_all_user_proxies(user_id: int) -> List[Dict]:
    """Get all proxies for a user"""
    cursor = proxies_col.find({"user_id": user_id}).sort("added_at", 1)
    proxies = []
    async for p in cursor:
        proxies.append({
            'id': str(p['_id']),
            'ip': p['ip'],
            'port': p['port'],
            'username': p.get('username'),
            'password': p.get('password'),
            'proxy_url': p['proxy_url'],
            'proxy_type': p.get('proxy_type', 'http'),
            'added_at': p.get('added_at')
        })
    return proxies

async def get_proxy_count(user_id: int) -> int:
    """Get count of user's proxies"""
    return await proxies_col.count_documents({"user_id": user_id})

async def remove_proxy_by_index(user_id: int, idx: int) -> Optional[Dict]:
    """Remove proxy by index position"""
    proxies = await get_all_user_proxies(user_id)
    if 0 <= idx < len(proxies):
        proxy = proxies[idx]
        await proxies_col.delete_one({"_id": ObjectId(proxy['id'])})
        return proxy
    return None

async def clear_all_proxies(user_id: int) -> int:
    """Remove all proxies for a user"""
    result = await proxies_col.delete_many({"user_id": user_id})
    return result.deleted_count

# ---------- SITE MANAGEMENT ----------
async def add_site_db(user_id: int, site: str) -> bool:
    """Add a site to user's collection"""
    try:
        await sites_col.update_one(
            {"user_id": user_id, "site": site},
            {"$setOnInsert": {
                "added_at": datetime.datetime.now(datetime.timezone.utc)
            }},
            upsert=True
        )
        return True
    except Exception as e:
        print(f"Error adding site: {e}")
        return False

async def get_user_sites(user_id: int) -> List[str]:
    """Get all sites for a user"""
    cursor = sites_col.find({"user_id": user_id})
    sites = []
    async for doc in cursor:
        sites.append(doc['site'])
    return sites

async def remove_site_db(user_id: int, site: str) -> bool:
    """Remove a site from user's collection"""
    result = await sites_col.delete_one({"user_id": user_id, "site": site})
    return result.deleted_count > 0

async def get_user_sites_count(user_id: int) -> int:
    """Get count of user's sites"""
    return await sites_col.count_documents({"user_id": user_id})

# ---------- KEY MANAGEMENT ----------
async def create_key(key: str, days: int, plans_type: str = "pro"):
    """Create a new plans key"""
    await keys_col.insert_one({
        "key": key,
        "days": days,
        "plans_type": plans_type,
        "used": False,
        "used_by": None,
        "used_at": None,
        "created_at": datetime.datetime.now(datetime.timezone.utc)
    })

async def get_key_data(key: str) -> Optional[Dict]:
    """Get key information"""
    doc = await keys_col.find_one({"key": key})
    if doc:
        return {
            'key': doc['key'],
            'days': doc['days'],
            'plans_type': doc['plans_type'],
            'used': doc['used'],
            'used_by': doc.get('used_by')
        }
    return None

async def use_key(user_id: int, key: str):
    """Redeem a plans key"""
    doc = await keys_col.find_one({"key": key, "used": False})
    if not doc:
        return False, "Invalid or already used key"
    
    days = doc['days']
    plans_type = doc['plans_type']
    
    # Mark key as used
    await keys_col.update_one(
        {"key": key},
        {"$set": {
            "used": True,
            "used_by": user_id,
            "used_at": datetime.datetime.now(datetime.timezone.utc)
        }}
    )
    
    # Update user plans
    await set_user_plans(user_id, plans_type, days)
    
    return True, f"{plans_type.upper()} plans activated for {days} days"

async def get_all_keys() -> List[Dict]:
    """Get all keys (admin function)"""
    cursor = keys_col.find().sort("created_at", -1)
    keys = []
    async for doc in cursor:
        keys.append({
            'key': doc['key'],
            'days': doc['days'],
            'plans_type': doc['plans_type'],
            'used': doc['used'],
            'used_by': doc.get('used_by'),
            'created_at': doc['created_at'],
            'used_at': doc.get('used_at')
        })
    return keys

async def delete_key(key: str) -> bool:
    """Delete a key"""
    result = await keys_col.delete_one({"key": key})
    return result.deleted_count > 0

# ---------- CARD STATS ----------
async def save_card_to_db(card: str, status: str, response: str, gateway: str, price: str):
    """Save card check result"""
    await cards_col.insert_one({
        "card": card,
        "status": status,
        "response": response,
        "gateway": gateway,
        "price": price,
        "checked_at": datetime.datetime.now(datetime.timezone.utc)
    })

# ---------- STATISTICS ----------
async def get_total_users() -> int:
    """Get total registered users"""
    return await users_col.count_documents({})

async def get_premium_count() -> int:
    """Get count of premium users"""
    now = datetime.datetime.now(datetime.timezone.utc)
    return await users_col.count_documents({
        "plans": {"$in": ["pro", "legend"]},
        "$or": [
            {"plans_expiry": None},
            {"plans_expiry": {"$gt": now}}
        ]
    })

async def get_total_sites_count() -> int:
    """Get total sites added"""
    return await sites_col.count_documents({})

async def get_total_cards_count() -> int:
    """Get total cards processed"""
    return await cards_col.count_documents({})

async def get_approved_count() -> int:
    """Get count of approved cards"""
    return await cards_col.count_documents({"status": "APPROVED"})

# ---------- CLEANUP FUNCTION ----------
async def close_db():
    """Close MongoDB connection"""
    mongo_client.close()
    print("✅ Database connection closed")